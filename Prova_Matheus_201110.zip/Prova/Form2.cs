﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prova
{
    public partial class Form2 : Form
    {
        private char campos;

        public Form2()
        {
            InitializeComponent();
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            textBox1.Text = monthCalendar1.SelectionRange.Start.ToLongDateString();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            StreamWriter arquivo;
            arquivo = new StreamWriter("festa.txt");
            //arquivo.WriteLine(WriteLine);
            arquivo.Close();
            MessageBox.Show("Arquivo gravado com sucesso!");
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            label4.Text = "";

            if (checkBox1.Checked)
            {
                checkBox1.Checked = false;
            }

            if (checkBox2.Checked)
            {
                checkBox2.Checked = false;
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                listBox1.Items.Add("safari - 2000.00");
                listBox1.Items.Add("Ladybug - 3000.00");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //MessageBoxButtons.Error("Selecione");
        }
    }
}
